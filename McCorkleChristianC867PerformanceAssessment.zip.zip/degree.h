#include <iostream>;
#include <iomanip>;
#include <string>;
using std::string;
using std::cout;

enum BookType { SECURITY, NETWORK, SOFTWARE };
static const std::string DegreeProgramStrings[] = { "SECURITY", "NETWORK", "SOFTWARE" };


